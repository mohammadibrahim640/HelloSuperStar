#include<stdio.h>
int main()
{
	int a[5]={2,4,5,7,1}; ///aitai array
	
	int i;
	
	
	for(i=0;i<5;i++){
		
		printf("%d\n",a[i]);
		
	}
	
	
	return 0;
	
	
}
