#include<stdio.h>
int main()
{
	int number;
	
	
	printf("Enter number:");
	scanf("%d",&number);
	
	switch(number){
		
		case 1:
		printf("First case");	
		break;
		
		case 2:
		printf("Second case");	
		break;
		
		case 3:
		printf("Third case");	
		break;
		
		case 4:
		printf("Fourth case");	
		break;
		
		
		deafult:
		printf("No case");		
		
		
		
		
	}
	
	
	return 0;
	
	
}
