#include<stdio.h>
int main()
{
	int number_1;
	
	printf("Enter the number :");
	scanf("%d",&number_1);
	
	
	if(number_1%2==0){
		
		printf("Even Number");
		
	}
	else
	{
			printf("Odd Number");
	}
	
	return 0;
	
}
