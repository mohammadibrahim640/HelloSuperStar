#include<stdio.h>
int main()
{
	int number,result;
	
	printf("Enter the number:");
	scanf("%d",&number);
	
	result=number+11111;
	
	printf("Result:%d",result);
	
	
	return 0;
	
	
}
