#include<stdio.h>
int main()
{
	float a;
    printf("Enter a float number:");
	scanf("%f",&a);
	printf("Number:%.2f",a);
    return 0;
	
}
