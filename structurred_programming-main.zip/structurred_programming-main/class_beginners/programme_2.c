#include<stdio.h>
int main()
{
	
	int a;
	
	printf("Enter the value of a: ");
	scanf("%d",&a);
	printf("Number:%d",a);
	
	
	return 0;
	
}
