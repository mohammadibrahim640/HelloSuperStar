#include<stdio.h>
int main()
{
	
	
	printf("Hello Bangladesh\n");
	printf("I am from daffodil");
	
	
	return 0;
	
}
