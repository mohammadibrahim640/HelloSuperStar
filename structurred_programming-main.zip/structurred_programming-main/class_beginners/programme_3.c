#include<stdio.h>
int main()
{
	
	int a,b;
	
	printf("Enter the value of a:");
	scanf("%d",&a);
	printf("Enter the value of b:");
	scanf("%d",&b);
	printf("Value of a=%d\n",a);
	printf("Value of b=%d",b);
	
	return 0;
	
}
